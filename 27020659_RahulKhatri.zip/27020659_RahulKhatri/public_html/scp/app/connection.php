<?php

    // Database credentials
    $user = "a2702065_user";
    $pw = "Toiohomai1234";
    $db = "a2702065_scp";

    // Database connection object (address, user, pw, db)
    $connection = new mysqli('localhost', $user, $pw, $db) or die(mysqli_error($connection));

    // Create variable that stores all records from our database
    $result = $connection->query("select * from subject") or die($connection->error());

    // first check if form has been submitted with data
    if(isset($_POST['submit']))
    {
        // Create variables from our posted form values
        $item_no = $_POST['item_no'];
        $object_class = $_POST['object_class'];
        $subject_image = $_POST['subject_image'];
        $procedures = $_POST['procedures'];
        $description = $_POST['description'];
        $reference = $_POST['reference'];
        

        // Create Insert SQL command to store above variables into database
        $sql = "insert into subject(item_no, object_class, subject_image, procedures, description, reference) values('$item_no', '$object_class', '$subject_image', '$procedures', '$description', '$reference')";

        // Display success or error messages
        if($connection->query($sql) === TRUE)
        {
            echo "
                <p>Record added successfully</p>
                <p><a href='../index.php'>Return to main page</a></p>
            ";
        }
        else
        {
            echo " 
                <p>There was an error submitting the data</p>
                <p>{$connection->error()}</p>
                <p><a href='../index.php'>Return to main page</a></p>
            ";
        }

    }


?>