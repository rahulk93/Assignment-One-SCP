<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Web Application</title>
  </head>
  <body class="container">
    <?php include "app/connection.php"; ?>
  <!-- Menu Row -->
    <div class="row">

      <div class="col">

        <ul class="nav navbar-light bg-light">

          <!-- run php loop thru db and display page names here-->
          <?php foreach($result as $item_no): ?>

            <li class="nav-item active">
            <a href="index.php?scp='<?php echo $item_no['item_no']; ?>'" class="nav-link"><?php echo $item_no['item_no']; ?></a>
          </li>

          <?php endforeach; ?>

          <li class="nav-item active">
            <a href="form.php" class="nav-link">Enter a new SCP Subject</a>
          </li>

        </ul>

      </div>

    </div>

    <!-- database content here -->
    <div class="row">

      <div class="col">
            <?php

              if(isset($_GET['scp']))
              {
                  // remove single quotes from page get value
                  $scp = trim($_GET['scp'], "'");

                  // run sql command to select record based on get value
                  $record = $connection->query("select * from subject where item_no='$scp'") or die($connection->error());

                  // convert $record into an array for us to echo out the individual fields on screen.
                  $row = $record->fetch_assoc();

                  // create variables that hold data from all table fields
                  $scp = $row['item_no'];
                  $class = $row['object_class'];
                  $image = $row['subject_image'];
                  
                  $procedures = $row['procedures'];
                  $description = $row['description'];
                  $reference = $row['reference'];

                  // Display information on screen
                  echo "

                      <h1>{$scp}</h1>
                      <h2>{$class}</h2>
                      <p><img src='{$image}'></p>
                      <p>{$procedures}</p>
                      <p>{$description}</p>
                      <p>{$reference}</p>
                  
                  ";
              }
              else
              {
                  // if this is the first time this page has been accessed, display content below
                  echo "
                    <h1>Welcome to this SCP website</h1>
                    <p class='text-center'>Use the links above to view pages stored in the database.</p>
                  
                  ";
              }

            ?>
      </div>

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>