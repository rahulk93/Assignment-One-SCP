<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Web Application</title>
  </head>
  <body class="container">

 <h1>Web Application</h1>
    <h2>Use the form to enter a new page record for SCP agents</h2>

    <form class="form-group" method="post" action="app/connection.php">

    <label>Enter SCP item number:</label>
    <br>
    <input type="text" class="form-control" name="item_no" placeholder="SCP item number should be in this arrangement: SCP-###" required>
    <br><br>
    <!-- The dropdown feature is from https://getbootstrap.com/docs/4.0/components/dropdowns/ website -->
    <label>Choose Subject class catagory:</label>
    <br>
    <select name="object_name" class="form-control" required>
    <option selected> Class catagories...</option>
    <option>Euclid</option>
    <option>Safe</option>
    <option>Keter</option>
    <option>Thaumiel</option>
    <option>Neutralized</option>
    </select>
    <br><br>
    <label>Enter a link to subject picture (if any available)</label>
    <br>
    <input type="text" class="form-control" name="subject_image" placeholder="The format in this textbox should be like this: pictures/picture_image.(gif, jpg, png)">
    <br><br>
    <label>Enter Containment Procedure Information:</label>
    <textarea name="procedure" class="form-control" rows="25" required></textarea>
    <br><br>
    <label>Enter Subject Description Information:</label>
    <textarea name="description" class="form-control" rows="25" required></textarea>
    <br><br>
    <label>Reference:</label>
    <textarea name="reference" class="form-control" rows="25" required></textarea>
    <br><br>
    <!-- The dropdown feature is from https://getbootstrap.com/docs/4.0/components/buttons/ website -->
    <input type="submit" class="btn btn-primary btn-lg btn-block" name="submit" value="Submit Page Information">

    </form>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>